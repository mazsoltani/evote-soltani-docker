<?php

use Illuminate\Http\Request;
use App\vote;
use App\election;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('CreateElection', 'ElectionController@CreateElection');
Route::post('EditElection', 'ElectionController@EditElection');
Route::post('RemoveElection', 'ElectionController@RemoveElection');
Route::post('IncremenetNumberOfVotes', 'ElectionController@IncremenetNumberOfVotes');
Route::get('getListOfChoices' , 'ElectionController@getListOfChoices');
Route::get('getAllElections' , 'ElectionController@getAllElections');
Route::get('electionExists' , 'ElectionController@electionExists');
Route::get('getElectionDetails','ElectionController@getElectionDetails');
/*
        List getListOfChoices(int electionId)
        void electionExists(int electionId)
        String getElectionDetails(int electionId)
  */



Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
