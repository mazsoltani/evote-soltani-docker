<?php

namespace App\Http\Controllers;

use App\election;
use Illuminate\Http\Request;
use Mockery\Exception;
use DB;

class ElectionController extends Controller
{
    public function CreateElection(Request $request)
    {
        try
        {
            $election = new election();
            $election->Title = $request->Title;
            $election->StartTime = $request->StartTime;
            $election->endtime = $request->EndTime;
            $election->ListOfChoices = $request->ListOfChoices;
            $election->NumberOfvotes = $request->NumberOfVotes;
            $election->save();
            return 'New Election Created...';
        }catch(Exception $e)
        {
            return 'Error...';
        }
    }

    public function EditElection(Request $request)
    {
        DB::table('elections')
            ->where('ID', $request->electionId)
            ->update([
                'Title'=> $request->Title,
                'StartTime' => $request->StartTime,
                'EndTime' => $request->EndTime,
                'ListOfChoices' => $request->ListOfChoices,
                'NumberOfVotes' => $request->NumberOfVotes,
            ]);
        return 'Election updated...';
    }

    public function RemoveElection(Request $request)
    {
        election::where('ID',$request->electionId)->delete();
        return 'Election Removed...';
    }

    public function IncremenetNumberOfVotes(Request $request)
    {
        DB::table('elections')
            ->where('ID', $request->electionid)
            ->update([
                'NumberOfVotes' => DB::raw('NumberOfVotes+1'),
            ]);
        return 'Increased Number Of Votes';
    }

    public function getListOfChoices(Request $request)
    {
        $result= election::where('ID',$request->electionId)->get(['ListOfChoices']);
        return \GuzzleHttp\json_encode($result);
    }

    public function getAllElections()
    {
        return election::all();
    }

    public function electionExists(Request $request)
    {
       $result= election::where('ID',$request->electionId)->get();
        if(count($result)>0)
            return 'This Election ID  Exist.';
        else
            return 'This Election ID Not Exist.';
    }

    public function getElectionDetails(Request $request)
    {
        $elctionid = $request->electionId;
        $result= election::where('ID',$elctionid)->get();
        return \GuzzleHttp\json_encode($result);

    }
}
